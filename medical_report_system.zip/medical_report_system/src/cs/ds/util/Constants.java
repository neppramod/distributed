package cs.ds.util;

public interface Constants {
    /* Change this to a directory where patient records reside in the client side */
    final String REPORT_DIR = "/tmp/PATIENT_RECORDS/";
}
